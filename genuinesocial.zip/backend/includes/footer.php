            </div>
            <footer class="admin-footer">
                <p>&copy; <?php echo date('Y'); ?> SocialIG Admin Panel. All rights reserved.</p>
            </footer>
        </main>
    </div>
    <script src="js/admin.js"></script>
</body>
</html>
